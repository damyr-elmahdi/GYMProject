export default function Home() {
  
  return (
    <>
      <h1 className="title">Latest Posts</h1>
    </>
  )
}